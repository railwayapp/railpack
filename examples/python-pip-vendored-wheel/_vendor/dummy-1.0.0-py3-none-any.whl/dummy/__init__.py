def hello():
    return "Hello from vendored package"
